package fr.tetiana.casino;

public class Caisse {
	private String referneceCaisse;
	private double montantCaisse;
	
	public Caisse() {
		super();
	}
	public String getReferneceCaisse() {
		return referneceCaisse;
	}
	public void setReferneceCaisse(String referneceCaisse) {
		this.referneceCaisse = referneceCaisse;
	}
	public double getMontantCaisse() {
		return montantCaisse;
	}
	public void setMontantCaisse(double montantCaisse) {
		this.montantCaisse = montantCaisse;
	}	
	
	
}
