package fr.tetiana.pharmacie;

public class Main {

	public static void main(String[] args) {
		
		new Menu();
		//Menu menu = new Menu();
		

	}

}
